create PROCEDURE read_from_csv(path VARCHAR2) as
 f_in utl_file.file_type;
 v_read VARCHAR2(4000);
 v_id NUMBER;
 v_nume VARCHAR2(15);
 v_prenume VARCHAR2(30);
 v_bursa NUMBER; 
 v_data_nastere DATE;
 v_array apex_application_global.vc_arr2;

 BEGIN 
    f_in:=UTL_FILE.FOPEN('MYDIR','test.csv','R');
    LOOP
    BEGIN
        utl_file.get_line(f_in,v_read);
        dbms_output.put_line(v_read);

        v_array := apex_util.string_to_table(v_read,',');

        v_id:=v_array(1);
        v_nume:=v_array(2);
        v_prenume:=v_array(3);
        v_bursa:=v_array(4);
        v_data_nastere:=v_array(5);

        INSERT INTO studenti_mici VALUES(
            v_id,
            v_nume,
            v_prenume,
            v_bursa,
            v_data_nastere
        );
        COMMIT;
    EXCEPTION
     WHEN OTHERS THEN
    EXIT;
    END; 
    END LOOP;
END;
/

