create PROCEDURE lab10(select_statement VARCHAR2) AS
v_cursor_id INT;
v_col_number INT;
v_col_string VARCHAR2(255);
v_col_date DATE;
v_ok INT;
v_desc_tab DBMS_SQL.DESC_TAB;
v_nr_col INT;
filename UTL_FILE.FILE_TYPE;
BEGIN
    v_cursor_id:=DBMS_SQL.OPEN_CURSOR();
    DBMS_SQL.PARSE(v_cursor_id,select_statement,DBMS_SQL.NATIVE);
    DBMS_SQL.DESCRIBE_COLUMNS(v_cursor_id,v_nr_col,v_desc_tab);

    FOR i IN 1 .. v_nr_col LOOP
        IF(v_desc_tab(i).col_type=2) THEN
            DBMS_SQL.define_column(v_cursor_id,i,v_col_number);
        ELSIF(v_desc_tab(i).col_type=12) THEN
            DBMS_SQL.define_column(v_cursor_id,i,v_col_date);
        ELSE
            DBMS_SQL.define_column(v_cursor_id,i,v_col_string,255);
        END IF;
    END LOOP;

    filename:=UTL_FILE.fopen('MYDIR','test2.csv','w');
    v_ok:=DBMS_SQL.EXECUTE(v_cursor_id);

    WHILE DBMS_SQL.FETCH_ROWS(v_cursor_id) > 0 LOOP
        FOR i IN 1 .. v_nr_col LOOP
            IF(v_desc_tab(i).col_type=2) THEN
                DBMS_SQL.COLUMN_VALUE(v_cursor_id,i,v_col_number);
                dbms_output.put_line(v_col_number);
                UTL_FILE.PUT(filename,v_col_number||',');
            ELSIF(v_desc_tab(i).col_type=12) THEN
                DBMS_SQL.COLUMN_VALUE(v_cursor_id,i,v_col_date);
                dbms_output.put_line(v_col_date);
                UTL_FILE.PUT(filename,v_col_date||',');
            ELSE
                DBMS_SQL.COLUMN_VALUE(v_cursor_id,i,v_col_string);
                dbms_output.put_line(v_col_string);
                UTL_FILE.PUT(filename,v_col_string||',');
            END IF;
        END LOOP;
        UTL_FILE.PUT_LINE(filename,'');
    END LOOP;
    UTL_FILE.FCLOSE(filename);
END;
/

