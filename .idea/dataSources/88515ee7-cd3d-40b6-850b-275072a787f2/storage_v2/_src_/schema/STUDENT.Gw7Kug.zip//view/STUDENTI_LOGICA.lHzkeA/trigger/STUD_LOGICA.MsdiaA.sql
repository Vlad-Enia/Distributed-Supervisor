create trigger STUD_LOGICA
    instead of insert
    on STUDENTI_LOGICA
    for each row
DECLARE
    id_max studenti.id%type;
    id_note_max note.id%type;
BEGIN
    SELECT MAX(id) INTO id_max FROM studenti;
    SELECT MAX(id) INTO id_note_max FROM studenti;
    INSERT INTO studenti(id,nr_matricol,nume,prenume,an,grupa,data_nastere) VALUES (id_max+1,'zzzzzz',:NEW.nume,:NEW.prenume,2,'B3',SYSDATE);
    INSERT INTO note(id,id_student,id_curs,valoare,data_notare,created_at,updated_at) VALUES (id_note_max+1,id_max+1,21,:NEW.valoare,SYSDATE,SYSDATE,SYSDATE);
END;
/

