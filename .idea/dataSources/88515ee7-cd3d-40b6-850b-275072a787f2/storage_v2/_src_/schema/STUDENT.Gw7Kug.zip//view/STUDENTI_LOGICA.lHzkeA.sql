create view STUDENTI_LOGICA as
SELECT s.nume, s.prenume,n.valoare FROM studenti s 
JOIN note n ON s.id=n.id_student 
JOIN cursuri c ON n.id_curs=c.id
WHERE c.titlu_curs='Logica' AND LOWER(s.grupa)='b3' AND s.an=2
/

create trigger STUD_LOGICA
    instead of insert
    on STUDENTI_LOGICA
    for each row
begin
    -- missing source code
end
/

