create trigger STUD
    instead of insert
    on CATALOG
    for each row
DECLARE
    max_nr_matricol studenti.nr_matricol%type;
    max_id studenti.id%type;
BEGIN
    SELECT MAX(nr_matricol) INTO max_nr_matricol FROM STUDENTI;
    SELECT MAX(id)INTO max_id FROM STUDENTI;
    INSERT INTO STUDENTI(id,nr_matricol,nume,prenume,an,grupa,data_nastere) VALUES (max_id+1,max_nr_matricol+1,:NEW.nume,:NEW.prenume,2,'B3',SYSDATE);
    INSERT INTO NOTE(id_student,id_curs,valoare) VALUES (max_id+1,1,:NEW.valoare);
END;
/

