create PROCEDURE print_select(v_querry VARCHAR2) AS
    v_cursor_id INT;
    v_col_str VARCHAR2(4000);
    v_col_num INT;
    v_col_date DATE;
    v_ok INT;
    v_rec_tab DBMS_SQL.DESC_TAB;
    v_nr_col INT;
    f_out UTL_FILE.FILE_TYPE;
BEGIN
    v_cursor_id := DBMS_SQL.OPEN_CURSOR();
    DBMS_SQL.PARSE(v_cursor_id,v_querry,DBMS_SQL.NATIVE);

    DBMS_SQL.DESCRIBE_COLUMNS(v_cursor_id, v_nr_col, v_rec_tab);

    FOR i IN 1 .. v_nr_col LOOP
        if (v_rec_tab(i).col_type = 2) then
            dbms_sql.define_column(v_cursor_id,i,v_col_num);
        elsif (v_rec_tab(i).col_type = 12) then
            dbms_sql.define_column(v_cursor_id,i,v_col_date);
        else
            dbms_sql.define_column(v_cursor_id,i,v_col_str,4000);
        end if;
    END LOOP;

    v_ok := DBMS_SQL.EXECUTE(v_cursor_id);

    f_out := UTL_FILE.fopen('MYDIR','querry.csv','w');

    WHILE (DBMS_SQL.FETCH_ROWS(v_cursor_id) > 0) LOOP
        FOR i IN 1 .. v_nr_col LOOP

                IF (v_rec_tab(i).col_type = 2) THEN
                    DBMS_SQL.COLUMN_VALUE(v_cursor_id,i,v_col_num);
                    dbms_output.put_line(v_col_num ||',');
                ELSIF (v_rec_tab(i).col_type = 12) THEN
                    DBMS_SQL.COLUMN_VALUE(v_cursor_id,i,v_col_date);
                    dbms_output.put_line(v_col_date ||',');
                ELSE
                    DBMS_SQL.COLUMN_VALUE(v_cursor_id,i,v_col_str);
                    dbms_output.put_line(v_col_str ||',');
                END IF;

        END LOOP;
        UTL_FILE.PUT_LINE(f_out,'');
    END LOOP;

    UTL_FILE.FCLOSE(f_out);
END;
/

