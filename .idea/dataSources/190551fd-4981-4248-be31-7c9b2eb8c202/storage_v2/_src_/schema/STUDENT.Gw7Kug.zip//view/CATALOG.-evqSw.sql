create view CATALOG as
SELECT s.nume, s.prenume, n.valoare
FROM STUDENTI s
JOIN NOTE n ON s.id = n.id_student
JOIN CURSURI c ON c.id = n.id_curs
WHERE c.titlu_curs = 'Logică' AND s.an = 2 and s.grupa = 'B3'
/

create trigger STUD
    instead of insert
    on CATALOG
    for each row
begin
    -- missing source code
end
/

