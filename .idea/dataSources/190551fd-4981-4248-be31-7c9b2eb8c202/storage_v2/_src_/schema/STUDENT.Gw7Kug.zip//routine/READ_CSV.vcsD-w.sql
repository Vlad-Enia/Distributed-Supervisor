create PROCEDURE read_csv AS
    v_fisier UTL_FILE.FILE_TYPE;
    v_id NUMBER;
    v_nume VARCHAR(100);
    v_prenume VARCHAR(100);
    v_bursa NUMBER;
    v_id_curs NUMBER;
    v_valoare NUMBER;
    v_data_notare DATE;
    v_line VARCHAR2(100);
    v_count NUMBER;
BEGIN
    v_fisier:=utl_file.fopen('MYDIR','catalog.csv','r');

    LOOP
    BEGIN
        utl_file.get_line(v_fisier, v_line);

        SELECT REGEXP_SUBSTR(v_line, '[^,]+', 1, 1)
        INTO v_id
        FROM DUAL;

        SELECT REGEXP_SUBSTR(v_line, '[^,]+', 1, 2)
        INTO v_nume
        FROM DUAL;

        SELECT REGEXP_SUBSTR(v_line, '[^,]+', 1, 3)
        INTO v_prenume
        FROM DUAL;

        SELECT REGEXP_SUBSTR(v_line, '[^,]+', 1, 4)
        INTO v_bursa
        FROM DUAL;

        SELECT REGEXP_SUBSTR(v_line, '[^,]+', 1, 5)
        INTO v_id_curs
        FROM DUAL;

        SELECT REGEXP_SUBSTR(v_line, '[^,]+', 1, 6)
        INTO v_valoare
        FROM DUAL;

        SELECT REGEXP_SUBSTR(v_line, '[^,]+', 1, 7)
        INTO v_data_notare
        FROM DUAL;


        SELECT COUNT(*) INTO v_count
        FROM CATALOG_STUDENTI
        WHERE nume = v_nume AND prenume = v_prenume AND bursa=v_bursa AND id_curs = v_id_curs AND valoare = v_valoare AND data_notare = v_data_notare;
        IF v_count > 0 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Content already exists');

        ELSE
            INSERT INTO CATALOG_STUDENTI VALUES (
                (select NVL(max(id), 0) + 1 from CATALOG_STUDENTI),
                v_nume,
                v_prenume,
                v_bursa,
                v_id_curs,
                v_valoare,
                v_data_notare
            );

        END IF; 
    EXCEPTION
        WHEN OTHERS THEN
            EXIT;
    END;
    END LOOP;
    utl_file.fclose(v_fisier);
END;
/

