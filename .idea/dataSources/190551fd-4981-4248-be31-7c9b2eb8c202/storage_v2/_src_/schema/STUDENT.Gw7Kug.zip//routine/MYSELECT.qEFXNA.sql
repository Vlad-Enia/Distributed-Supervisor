create PROCEDURE myselect(v_querry VARCHAR2) AS
    v_cursor_id INT;

    numvar INT;
    strvar VARCHAR2(100);
    datevar DATE;

    v_ok INT;
    v_rec_tab DBMS_SQL.DESC_TAB;
    v_nr_col INT;
    f_out UTL_FILE.FILE_TYPE;
BEGIN
    v_cursor_id := DBMS_SQL.OPEN_CURSOR();
    DBMS_SQL.PARSE(v_cursor_id,v_querry,DBMS_SQL.NATIVE);

    DBMS_SQL.DESCRIBE_COLUMNS(v_cursor_id, v_nr_col, v_rec_tab);

    FOR i IN 1 .. v_nr_col LOOP
        if (v_rec_tab(i).col_type = 1) then
            dbms_sql.define_column(v_cursor_id, i, strvar,100);
        elsif (v_rec_tab(i).col_type = 2) then
            dbms_sql.define_column(v_cursor_id, i, numvar);
        else
            dbms_sql.define_column(v_cursor_id, i, datevar);
        end if;
    END LOOP;

    v_ok := DBMS_SQL.EXECUTE(v_cursor_id);


    WHILE (DBMS_SQL.FETCH_ROWS(v_cursor_id) > 0) LOOP
        FOR i IN 1 .. v_nr_col LOOP

                IF (v_rec_tab(i).col_type = 1) THEN
                    DBMS_SQL.COLUMN_VALUE(v_cursor_id, i, strvar);
                    dbms_output.put_line(strvar || ',');
                ELSIF (v_rec_tab(i).col_type = 2) THEN
                    DBMS_SQL.COLUMN_VALUE(v_cursor_id, i, numvar);
                    dbms_output.put_line(numvar || ',');
                ELSE
                    DBMS_SQL.COLUMN_VALUE(v_cursor_id, i, datevar);
                    dbms_output.put_line(datevar || ',');  
                END IF;

        END LOOP;

    END LOOP;
    UTL_FILE.FCLOSE(f_out);
END;
/

