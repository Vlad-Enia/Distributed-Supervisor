create PROCEDURE importa AS
    v_fisier UTL_FILE.FILE_TYPE;
    v_fisier:=utl_file.fopen('MYDIR','catalog.csv','W');
    UTL_file.put_line(v_fisier.'Studenti');
for linie in test loop
    SELECT * from studenti into linie
    utl_file.put(v_fisier,linie.nume);
    utl_file.put(v_fisier,','||linie.prenume);
    utl_file.put(v_fisier,','||linie.bursa);
    utl_file.put(v_fieiser,','|linie.data_nastere);
    utl_file.new_line(v_fisier);    
END
/

